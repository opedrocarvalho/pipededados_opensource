from langchain_ollama import ChatOllama
import os
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import asyncio
from typing import List
from pydantic import BaseModel
from browser_use.agent.service import Agent
from browser_use.controller.service import Controller

controller = Controller()

URLS = [
    "https://www.solferias.pt/#home",
    "https://www.transalpino.pt/"
]

TASK_TEMPLATE = (
"Open the browser and navigate to the website {url}."
"On the site, find and enter the section labeled 'Brazil' or 'Brasil'."
"Within this section, identify the destinations along with their respective prices in euros (€)."
"Return a list containing exclusively the Brazilian destinations found and their corresponding prices in euros."
)

class Model(BaseModel):
	url: str
	city: str
	price: str 

class Models(BaseModel):
	models: List[Model]

@controller.action('Save models', param_model=Models)
def save_models(params: Models):
	with open('models.txt', 'a') as f:
		for model in params.models:
			f.write(f'{model.url} ({model.city}) {model.price}\n')

async def main():
    model = ChatOllama(model='deepseek-r1:8b', num_ctx=4096)

    for url in URLS:
        task = TASK_TEMPLATE.format(url=url)
        agent = Agent(task=task, llm=model, controller=controller)
        await agent.run()

if __name__ == "__main__":
    asyncio.run(main())